TitTotTat TEST RELEASE VERSION 0.3.0.2106
by Edgar Su


How To Play Spilt-Screened on One Computer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    TitTotTat provides local spilt-screen playing capabilities on ONE DEVICE. To do that, press
the "Play Spilt-Screened" button on Scene Connection. Another game window will pop up and will
automaticly connect.
    Press the "K" key when the window is selected to switch controlling modes.

Control Modes:
isSpiltControl: True:
    Move Up: W
    Turn Left/Right: A/D
    Shoot: C
    Docking Mode: V
isSpiltControl: False:
    Move Up: UpArrow
    Turn Left/Right: Left/RightArrow
    Shoot: SpaceKey
    Docking Mode: L
